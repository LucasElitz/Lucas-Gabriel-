
import streamlit as st
from transformers import pipeline
import emoji

# Configuração da página
st.set_page_config(page_title="Análise de Sentimentos - ReclameAqui", layout="wide")

# Título
st.title("💬 Análise de Sentimentos de Reclamações")

# Instruções
st.markdown("""
Digite ou cole uma reclamação abaixo para identificar o sentimento do texto.
""")

# Entrada de texto
texto = st.text_area("Reclamação", height=200)

# Botão para analisar
if st.button("Analisar Sentimento"):
    if texto.strip() == "":
        st.warning("Por favor, digite uma reclamação para analisar.")
    else:
        # Pipeline de sentimentos da Hugging Face
        analise = pipeline("sentiment-analysis")
        resultado = analise(texto)[0]
        
        sentimento = resultado['label']
        confianca = resultado['score']

        st.write("### Resultado")
        st.write(f"**Sentimento:** {emoji.emojize(sentimento)}")
        st.write(f"**Confiança:** {confianca:.2%}")
